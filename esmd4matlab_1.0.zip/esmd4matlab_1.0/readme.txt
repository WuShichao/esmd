set esmd4matlab_1.0 directory the current one in matlab workspace. 
Then in matlab command window:
run steps:
1. run_1.m
2. set optLoop according the output figure or adopt the default value
3. run_2.m 
