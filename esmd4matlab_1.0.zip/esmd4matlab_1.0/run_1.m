disp('It is running. Please wait ...');
clear all;
javaaddpath(pwd);
esmd= esmd4j.Esmd();


% load data
data=load('winddata.txt');
Y=data(:,1);

delt_t = 0.05; % sampling period 
t=esmd.init_t(length(Y),delt_t);

%parameters setting:
minLoop=1;
maxLoop=40;
extremeNumR=4; % >=4
jianGeNum = 1; %

rList = esmd.getVarianceRatio(t, Y, minLoop, maxLoop, extremeNumR);

[minVar,idx]=min(rList);
optLoop=idx+minLoop-1;
disp('optimal loop is: ');
fprintf('optLoop=%d\n',optLoop);

%-----------------------------------
x=minLoop:maxLoop;
figure(1)
plot(x,rList)

