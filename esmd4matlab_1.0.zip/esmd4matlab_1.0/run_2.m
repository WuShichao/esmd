%parameters setting:

esmd.getSift(t, Y, optLoop, extremeNumR);

%-------------------------------------------
len = esmd.yImfsR.size();
figure(2)
for i=1:len
	subplot(len,1,i);
	plot(t, esmd.yImfsR.get(i-1));
	%xlabel('t');
	if i==1
		ylabel('Y');
	elseif i==len
		ylabel('R');
	else
		ylabel(strcat('Imf',num2str(i-1)));
	end
end

%-------------------------------------------
len=esmd.interfs.size();
figure(3)
%frequency distribution figure
for i=1:len
	plot(t,esmd.interfs.get(i-1))
	hold on
end

%-------------------------------------------
figure(4)
%frequency Amplitude figure
for i=1:len
	subplot(2*len,1,2*i-1)
	plot(t,esmd.interfs.get(i-1))
	ylabel(strcat('F',num2str(i)))

	subplot(2*len,1,2*i)
	plot(t,esmd.upperEvelops.get(i-1))
	ylabel(strcat('A',num2str(i)))
end

%-------------------------------------------
figure(5)
%AdaptGlobalMeanCurve on Y
len = esmd.yImfsR.size();
plot(t,Y);
hold on;
R=esmd.yImfsR.get(len-1);
plot(t,R);

%-------------------------------------------
figure(6)
%plot Y-R  
plot(t,Y-R)

%-------------------------------------------
figure(7)
plot(t,esmd.energy)

%clear all;
%javarmpath(pwd);
